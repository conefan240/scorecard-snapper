import { useEffect, useState } from "react";

export type Theme = "light" | "dark";

export const THEME_STORAGE_KEY = "fairway.theme.v1";

function persistTheme(theme: Theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#000000" : "#ffffff");
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
    // localStorage may be unavailable (private browsing, etc). Theme just won't persist.
  }
}

/**
 * Reads and writes the app's color theme:
 * - "light" = white surfaces with the green brand accent
 * - "dark"  = black surfaces with the green brand accent
 *
 * The `dark` class on <html> is set synchronously by an inline script in
 * __root.tsx, before React hydrates, so there's no flash of the wrong
 * theme on load. This hook always starts at "light" (matching the
 * server-rendered markup) and corrects itself from the DOM right after
 * mount, which keeps hydration consistent.
 */
export function useTheme() {
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    const current = document.documentElement.classList.contains("dark") ? "dark" : "light";
    setTheme(current);
  }, []);

  function toggleTheme() {
    setTheme((prev) => {
      const next: Theme = prev === "dark" ? "light" : "dark";
      persistTheme(next);
      return next;
    });
  }

  return { theme, toggleTheme };
}
